package bcc266TP2.toy;

public class BlocoMemoria {
	
	 //BlocoMemoria.palavras[0] => um dado da ram
	
	 int[] palavras = new int[4];
	 int endBloco = 0;
	 boolean atualizado = false;
	 int custo = 0;
	 int cacheHit = 0;	
	
}
