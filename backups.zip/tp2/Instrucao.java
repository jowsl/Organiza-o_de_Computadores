package bcc266TP2.toy;

public class Instrucao {
	Endereco add1;
	Endereco add2;
	Endereco add3;
	int opcode;
}
