package bcc266TP2.toy;

public class Endereco {
	int endBloco;
	int endPalavra;
	
}
